package com.nagarro.sample.assignment.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import com.nagarro.sample.assignment.service.UserDetailsServiceImpl;

/**
* @author Arunkumar Haridoss
* 
* 		This Page is used for login, maintaining the session and Redirecting to respective pages. 
* 		This is using Spring Security functionalities
*
*/


@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	/*
	 * @Autowired UserDetailsServiceImpl userDetailsService;
	 * 
	 * 
	 */
	
	
	@Autowired
	AuthenticationSuccessHandler successHandler;
	
	@Value("${userPass}")
	private String userPass;
	
	@Value("${adminPass}")
	private String adminPass;
	
	private static final Logger log = LoggerFactory.getLogger(WebSecurityConfig.class);

	// Session Management Registration

	@Bean
	public SessionRegistry sessionRegistry() {
		return new SessionRegistryImpl();
	}

	// Login Password Encryption
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
		return bCryptPasswordEncoder;
	}

	// Setting Service to find User in the database.
	// And Setting PassswordEncoder



	
	@Override
	public void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.inMemoryAuthentication()
			.withUser("user").password(userPass).roles("USER")
			.and()
			.withUser("admin").password(adminPass).roles("ADMIN");  // We can save the user credentials in database and we can fetch the same if required. 
	}

	@Override
	public void configure(HttpSecurity http) throws Exception {
		http
			.csrf().disable()
			.authorizeRequests()
			.antMatchers("/user").hasAnyRole("USER")
			.antMatchers("/admin").hasAnyRole("ADMIN")
			.and().formLogin().loginProcessingUrl("/j_spring_security_check").loginPage("/login")
				.successHandler(successHandler)
			.permitAll()
			.and().logout().logoutUrl("/logout").logoutSuccessUrl("/login")
			.and().sessionManagement() // Session Management
			.maximumSessions(1) // Maximum Allowed customer per User and multiple login prevention
			.maxSessionsPreventsLogin(true).sessionRegistry(sessionRegistry());
		
			http.sessionManagement().invalidSessionUrl("/login");
	}
	

	@Bean
	public HttpSessionEventPublisher httpSessionEventPublisher() {
		return new HttpSessionEventPublisher();
	}

}
