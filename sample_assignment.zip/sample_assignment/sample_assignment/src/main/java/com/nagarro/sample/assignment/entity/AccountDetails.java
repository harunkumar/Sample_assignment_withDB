package com.nagarro.sample.assignment.entity;

/**
 * @author Arunkumar Haridoss
 * 
 *         This model is using for generating Account Statement
 *
 */
public class AccountDetails {

	private int Id;
	private String accountType;
	private String amount;
	private String date;
	private String accountNumber;

	public AccountDetails(int id, String accountType, String amount, String date, String accountNumber) {
		super();
		Id = id;
		this.accountType = accountType;
		this.amount = amount;
		this.date = date;
		this.accountNumber = accountNumber;
	}

	public AccountDetails() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

}
