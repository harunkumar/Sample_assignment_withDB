package com.nagarro.sample.assignment.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.nagarro.sample.assignment.entity.Users;

/**
 * @author Arunkumar Haridoss
 * 
 *         This service is using for login credential details fetching and
 *         throwing error
 *
 */
@Service
public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {

		Users user = null;
		try {
			user = findByUsername(userName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			throw new UsernameNotFoundException("Please enter the valid Username & Password");
		}

		if (user == null) {
			System.out.println("User not found! " + userName);
			throw new UsernameNotFoundException("User " + userName + " was not found in the database");
		}

		// [ROLE_USER, ROLE_ADMIN,..]
		List<String> roleNames = new ArrayList();
		roleNames.add(user.getRole());

		List<GrantedAuthority> grantList = new ArrayList<GrantedAuthority>();
		if (roleNames != null) {
			for (String role : roleNames) {
				// ROLE_USER, ROLE_ADMIN,..
				GrantedAuthority authority = new SimpleGrantedAuthority(role);
				grantList.add(authority);
			}
		}

		UserDetails userDetails = (UserDetails) new User(user.getUsername(), // Getting user Details
				user.getPassword(), grantList);

		return userDetails;
	}

	public Users findByUsername(String userName) {

		Users user = jdbcTemplate.queryForObject(UserMapper.BASE_SQL + " where u.username = ?",
				new Object[] { userName }, new UserMapper());

		return user;

	}

}