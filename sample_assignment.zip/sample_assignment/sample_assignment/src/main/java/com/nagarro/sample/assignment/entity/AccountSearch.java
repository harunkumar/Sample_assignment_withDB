package com.nagarro.sample.assignment.entity;

/**
 * @author Arunkumar Haridoss
 * 
 *         This entity is using for form submission to fetch the user provided
 *         data
 *
 */
public class AccountSearch {

	private int accountID;
	private String miAmount;

	private String mAmount;
	private String fDate;
	private String tDate;

	public int getAccountID() {
		return accountID;
	}

	public void setAccountID(int accountID) {
		this.accountID = accountID;
	}

	public String getMiAmount() {
		return miAmount;
	}

	public void setMiAmount(String miAmount) {
		this.miAmount = miAmount;
	}

	public String getmAmount() {
		return mAmount;
	}

	public void setmAmount(String mAmount) {
		this.mAmount = mAmount;
	}

	public String getfDate() {
		return fDate;
	}

	public void setfDate(String fDate) {
		this.fDate = fDate;
	}

	public String gettDate() {
		return tDate;
	}

	public void settDate(String tDate) {
		this.tDate = tDate;
	}

	@Override
	public String toString() {
		return "accountSearch [accountID=" + accountID + ", miAmount=" + miAmount + ", mAmount=" + mAmount + ", fDate="
				+ fDate + ", tDate=" + tDate + "]";
	}

}
