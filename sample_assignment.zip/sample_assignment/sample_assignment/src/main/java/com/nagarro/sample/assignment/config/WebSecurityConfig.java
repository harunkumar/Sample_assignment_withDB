package com.nagarro.sample.assignment.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import com.nagarro.sample.assignment.service.UserDetailsServiceImpl;

/**
* @author Arunkumar Haridoss
* 
* 		This Page is used for login, maintaining the session and Redirecting to respective pages. 
* 		This is using Spring Security functionalities
*
*/


@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	UserDetailsServiceImpl userDetailsService;

	private static final Logger log = LoggerFactory.getLogger(WebSecurityConfig.class);

	// Session Management Registration

	@Bean
	public SessionRegistry sessionRegistry() {
		return new SessionRegistryImpl();
	}

	// Login Password Encryption
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
		return bCryptPasswordEncoder;
	}

	// Setting Service to find User in the database.
	// And Setting PassswordEncoder

	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {

		try {
			auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder());
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

	}


	@Override
	protected void configure(HttpSecurity http) throws Exception {

		log.info("Function for login details provided by Spring Security");

		http.csrf().disable();

		// The pages does not require login
		http.authorizeRequests().antMatchers("/", "/login", "/logout").permitAll();

		// AccessDeniedException will be thrown.
		http.authorizeRequests().and().exceptionHandling().accessDeniedPage("/403");

		// Config for Login Form
		http.authorizeRequests().and().formLogin()
				// Submit URL of login page.
				.loginProcessingUrl("/j_spring_security_check") // Submit URL
				.loginPage("/login")
				.defaultSuccessUrl("/accountdetails")// Once Login Success application redirect to mentioned URL
				.failureUrl("/login?error=true")// Once Login Failure application redirect to mentioned URL
				.usernameParameter("username").passwordParameter("password")
				// Config for Logout Page
				.and().logout().logoutUrl("/logout").logoutSuccessUrl("/login")
				.and().sessionManagement() // Session Management
				.maximumSessions(1) // Maximum Allowed customer per User and multiple login prevention
				.maxSessionsPreventsLogin(true).sessionRegistry(sessionRegistry());

		http.sessionManagement().invalidSessionUrl("/login");

	}

	@Bean
	public HttpSessionEventPublisher httpSessionEventPublisher() {
		return new HttpSessionEventPublisher();
	}

}
