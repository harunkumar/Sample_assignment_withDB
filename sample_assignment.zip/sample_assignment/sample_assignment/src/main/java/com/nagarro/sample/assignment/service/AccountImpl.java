package com.nagarro.sample.assignment.service;

import java.text.SimpleDateFormat;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import com.nagarro.sample.assignment.entity.AccountDetails;
import com.nagarro.sample.assignment.entity.AccountSearch;

/**
 * @author Arunkumar Haridoss
 * 
 *         This service is using for generate the account statement
 *
 */
@Service
public class AccountImpl {

	@Autowired
	JdbcTemplate jdbcTemplate;

	public List<AccountDetails> getAccountDetails(AccountSearch accountSearch) {

		String qry = "";

		try {

			SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
			String strDate = "";

			String maxDate = (String) jdbcTemplate
					.queryForObject("select FORMAT( max(s.dateField), 'dd-MM-yy') from statement s", String.class);

			System.out.println("maxDate::: " + maxDate);

		//	Object[] object = new Object[] { 0 };

			if (accountSearch.getAccountID() > 0 && accountSearch.getfDate().length()>0
					&& accountSearch.getmAmount().length()>0) {

				/*
				 * object = new Object[] { accountSearch.getAccountID(),
				 * accountSearch.getfDate(), accountSearch.gettDate(),
				 * accountSearch.getMiAmount(), accountSearch.getmAmount() };
				 */
				qry = " and a.id= '" + accountSearch.getAccountID() + "' and s.datefield BETWEEN '"
						+ accountSearch.getfDate() + "' AND '" + accountSearch.gettDate() + "' and s.amount BETWEEN '"
						+ accountSearch.getMiAmount() + "' AND '" + accountSearch.getmAmount() + "' ";
				
				 System.out.println("qry1 :::::" + qry);
			} else if (accountSearch.getAccountID() > 0 && accountSearch.getmAmount().length()>0) {

				qry = " and a.id= '" + accountSearch.getAccountID() + "' and s.amount BETWEEN '"
						+ accountSearch.getMiAmount() + "' AND '" + accountSearch.getmAmount() + "' ";
				
				 System.out.println("qry2 :::::" + qry);

			} else if (accountSearch.getAccountID() > 0){

				// strDate= formatter.format((String)accountSearch.getfDate());

				// System.out.println("strDate :::::"+strDate);

				

				qry = " and a.id= '" + accountSearch.getAccountID() + "'";
				
				 System.out.println("qry3 :::::" + qry);

			}

			
			qry = "SELECT a.id,a.account_type,s.amount,s.datefield,a.account_number FROM account a, statement s where a.id = s.account_id "
					+ qry;
			
			System.out.println("qry4 :::::" + qry);
			List<AccountDetails> account = jdbcTemplate.query(
					qry,
					new AccountMapper());
			return account;

		} catch (Exception ex) {

			return jdbcTemplate.query(
					"SELECT a.id,a.account_type,s.amount,s.datefield,a.account_number FROM account a, statement s where a.id = s.account_id and "
							+ qry,
					new AccountMapper());

		}

	}

}
