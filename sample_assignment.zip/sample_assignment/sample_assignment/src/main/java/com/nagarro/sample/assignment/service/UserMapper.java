package com.nagarro.sample.assignment.service;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.nagarro.sample.assignment.entity.Users;

/**
 * @author Arunkumar Haridoss
 * 
 *         This Mapper is using for assigning the resultset values.
 *
 */
public class UserMapper implements RowMapper<Users> {

	public static final String BASE_SQL //
			= "Select u.Id, u.username, u.password,u.role From Users u ";

	@Override
	public Users mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		Long userId = rs.getLong("id");
		String userName = rs.getString("username");
		String encrytedPassword = rs.getString("password");
		String role = rs.getString("role");

		return new Users(userId, userName, encrytedPassword, role);
	}
}
